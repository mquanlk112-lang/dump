# Build NOVAKIT iOS IPA

## GitHub Actions

1. Keep this project ZIP in the repository root (or extract its `NOVAKIT` folder into the repository root if using the direct-source workflow).
2. Open **Actions** and run **Build NOVAKIT iOS IPA**.
3. Download the `NOVAKIT-unsigned-IPA` artifact after the workflow completes.

The workflow uses a GitHub-hosted macOS runner with Xcode. It builds the `NOVAKIT` scheme for generic iOS devices and packages `NOVAKIT-unsigned.ipa`.

This artifact is unsigned. Normal installation on an iPhone requires an authorized signing method and, where applicable, a matching provisioning profile.

## Compatibility

The project deployment target is iOS 16.0 (compatible with iOS 16.7.16). It uses public SwiftUI/UIKit APIs and a user-controlled Files document picker for access to explicitly selected directories. The app cannot access another app's private sandbox or obtain unrestricted filesystem permissions.

## Local Xcode build

Open `NOVAKIT.xcodeproj`, select scheme `NOVAKIT`, choose an iPhone device or `Any iOS Device (arm64)`, configure signing, and build/archive.
