import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var store: AppStore
    @Binding var selection: Int

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 22) {
                    header
                    hero
                    quickStats
                    quickActions
                    recentActivity
                    footer
                }
                .padding(.horizontal, 18)
                .padding(.top, 12)
                .padding(.bottom, 28)
            }
            .nkScreen()
            .toolbar(.hidden, for: .navigationBar)
        }
        .onAppear { store.refreshPackages() }
    }

    private var header: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 15, style: .continuous)
                    .fill(NKTheme.heroGradient)
                    .frame(width: 48, height: 48)
                Image(systemName: "hexagon.fill")
                    .font(.system(size: 23, weight: .bold))
                    .foregroundStyle(.white)
                    .overlay {
                        Image(systemName: "sparkle")
                            .font(.system(size: 10, weight: .black))
                            .foregroundStyle(.white)
                    }
            }
            VStack(alignment: .leading, spacing: 2) {
                Text("NOVA KIT")
                    .font(.system(size: 19, weight: .black, design: .rounded))
                    .tracking(1.4)
                    .foregroundStyle(.white)
                Text("DEVICE WORKSPACE")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(1.7)
                    .foregroundStyle(NKTheme.muted)
            }
            Spacer()
            NKTag(title: "Local-first", color: NKTheme.green)
        }
    }

    private var hero: some View {
        ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 26, style: .continuous)
                .fill(NKTheme.heroGradient)
            Circle()
                .fill(.white.opacity(0.12))
                .frame(width: 170, height: 170)
                .offset(x: 235, y: -36)
            Circle()
                .stroke(.white.opacity(0.18), lineWidth: 1)
                .frame(width: 210, height: 210)
                .offset(x: 220, y: 60)
            VStack(alignment: .leading, spacing: 12) {
                NKTag(title: "Workspace 01", color: .white)
                Text("Your device.\nYour workspace.")
                    .font(.system(size: 29, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .fixedSize(horizontal: false, vertical: true)
                Text("Organize files, inspect packages and build portable patch manifests.")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(.white.opacity(0.82))
                    .lineSpacing(3)
                    .frame(maxWidth: 245, alignment: .leading)
                Button {
                    selection = 2
                } label: {
                    HStack(spacing: 8) {
                        Text("Open workspace")
                        Image(systemName: "arrow.up.right")
                    }
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(NKTheme.background)
                    .padding(.horizontal, 15)
                    .padding(.vertical, 11)
                    .background(.white, in: Capsule())
                }
                .buttonStyle(.plain)
                .padding(.top, 2)
            }
            .padding(21)
        }
        .frame(height: 260)
        .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
    }

    private var quickStats: some View {
        HStack(spacing: 10) {
            statCard(value: "\(store.packages.count)", title: "PACKAGES", icon: "shippingbox", tint: NKTheme.cyan)
            statCard(value: "\(store.items(in: "").count)", title: "WORKSPACE ITEMS", icon: "folder", tint: NKTheme.violet)
            statCard(value: "\(store.activities.count)", title: "ACTIVITY", icon: "waveform.path", tint: NKTheme.green)
        }
    }

    private func statCard(value: String, title: String, icon: String, tint: Color) -> some View {
        NKCard(padding: 13) {
            VStack(alignment: .leading, spacing: 10) {
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(tint)
                Text(value)
                    .font(.system(size: 23, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .contentTransition(.numericText())
                Text(title)
                    .font(.system(size: 8, weight: .heavy, design: .rounded))
                    .tracking(0.8)
                    .foregroundStyle(NKTheme.muted)
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var quickActions: some View {
        VStack(alignment: .leading, spacing: 12) {
            NKSectionTitle(title: "Quick actions", subtitle: "Pick up where you left off")
            HStack(spacing: 10) {
                actionCard(title: "Import package", subtitle: ".3105 · .1411 · ZIP", icon: "square.and.arrow.down", tint: NKTheme.cyan) {
                    selection = 1
                }
                actionCard(title: "Create patch", subtitle: "Portable manifest", icon: "hammer.fill", tint: NKTheme.violet) {
                    selection = 3
                }
            }
            HStack(spacing: 10) {
                actionCard(title: "Browse files", subtitle: "Local workspace", icon: "folder.badge.gearshape", tint: NKTheme.green) {
                    selection = 2
                }
                actionCard(title: "Device info", subtitle: "Read-only details", icon: "iphone.gen3", tint: NKTheme.orange) {
                    selection = 4
                }
            }
        }
    }

    private func actionCard(title: String, subtitle: String, icon: String, tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            NKCard(padding: 14) {
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: icon)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(tint)
                        .frame(width: 35, height: 35)
                        .background(tint.opacity(0.13), in: RoundedRectangle(cornerRadius: 11))
                    VStack(alignment: .leading, spacing: 4) {
                        Text(title)
                            .font(.system(size: 12, weight: .bold))
                            .foregroundStyle(.white)
                        Text(subtitle)
                            .font(.system(size: 9, weight: .medium))
                            .foregroundStyle(NKTheme.muted)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 0)
                }
            }
        }
        .buttonStyle(.plain)
    }

    private var recentActivity: some View {
        VStack(alignment: .leading, spacing: 12) {
            NKSectionTitle(title: "Recent activity", subtitle: "Actions performed on this device")
            if store.activities.isEmpty {
                NKCard {
                    Text("No activity yet.")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(NKTheme.muted)
                }
            } else {
                NKCard(padding: 0) {
                    VStack(spacing: 0) {
                        ForEach(Array(store.activities.prefix(4).enumerated()), id: \.element.id) { index, item in
                            HStack(spacing: 11) {
                                Circle()
                                    .fill(NKTheme.cyan.opacity(0.16))
                                    .frame(width: 30, height: 30)
                                    .overlay(Image(systemName: "checkmark")
                                        .font(.system(size: 11, weight: .bold))
                                        .foregroundStyle(NKTheme.cyan))
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(item.title)
                                        .font(.system(size: 12, weight: .semibold))
                                        .foregroundStyle(.white)
                                    Text(item.detail)
                                        .font(.system(size: 10))
                                        .foregroundStyle(NKTheme.muted)
                                }
                                Spacer()
                                Text(item.date, style: .time)
                                    .font(.system(size: 9, weight: .medium, design: .rounded))
                                    .foregroundStyle(NKTheme.muted)
                            }
                            .padding(13)
                            if index < min(store.activities.count, 4) - 1 {
                                Rectangle().fill(NKTheme.line).frame(height: 1).padding(.leading, 54)
                            }
                        }
                    }
                }
            }
        }
    }

    private var footer: some View {
        HStack {
            Text("NOVAKIT · BUILD 1.0")
            Spacer()
            Text("LOCAL STORAGE")
        }
        .font(.system(size: 8, weight: .heavy, design: .rounded))
        .tracking(1.1)
        .foregroundStyle(NKTheme.muted.opacity(0.75))
        .padding(.top, 4)
    }
}
