import SwiftUI

struct SettingsView: View {
    @AppStorage("novakit.compactMode") private var compactMode = false
    @AppStorage("novakit.haptics") private var hapticsEnabled = true

    var body: some View {
        Form {
            Section("Appearance") {
                Toggle("Compact layout", isOn: $compactMode)
                Toggle("Haptic feedback preference", isOn: $hapticsEnabled)
            }
            Section("About") {
                LabeledContent("Version", value: "1.0 (1)")
                LabeledContent("Bundle", value: "com.minhquandev.novakit")
                LabeledContent("Storage", value: "Local app sandbox")
            }
            Section {
                Text("NOVAKIT is an independent workspace utility. It is not affiliated with the 3105 project or the BEU/TELE distributor.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .scrollContentBackground(.hidden)
        .background(NKTheme.background)
        .preferredColorScheme(.dark)
        .navigationTitle("Settings")
    }
}
