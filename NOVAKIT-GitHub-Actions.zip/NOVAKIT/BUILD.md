# Build NOVAKIT.ipa

## Build with GitHub Actions

1. Upload the contents of this project to a GitHub repository. Upload the contents of the extracted `NOVAKIT` folder to the repository root. The root must contain `.github/`, `NOVAKIT.xcodeproj/`, and `NovaKit/`.
2. Open the repository's **Actions** tab.
3. Select **Build NOVAKIT iOS IPA** and choose **Run workflow**. A push to `main` or `master` that changes files under `NOVAKIT/` also starts a build.
4. When the run completes, open the run and download the `NOVAKIT-unsigned-IPA` artifact.

The workflow runs on a GitHub-hosted macOS runner with Xcode. It builds the `NOVAKIT` scheme for generic iOS devices and packages the app as `NOVAKIT-unsigned.ipa`.

**Signing note:** this workflow produces an **unsigned** IPA. It is a build artifact, not an Apple-signed install package. Normal installation on an iPhone requires a valid signing method and, where applicable, a matching provisioning profile. Do not assume this unsigned IPA can be installed directly through the iOS Files app. A separate signing step can be added when you have a certificate and provisioning profile you are authorized to use.

## Build locally with Xcode

Requirements: macOS with Xcode 15 or later.

1. Open `NOVAKIT.xcodeproj` in Xcode.
2. Select the `NOVAKIT` scheme and an iPhone device or `Any iOS Device (arm64)`.
3. In **Signing & Capabilities**, enable **Automatically manage signing** and select your Team.
4. Build and run, or choose **Product → Archive** and export using the distribution method appropriate for your device.
