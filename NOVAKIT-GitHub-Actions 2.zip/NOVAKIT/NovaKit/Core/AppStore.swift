import Foundation
import Combine
import CryptoKit

struct WorkspaceItem: Identifiable {
    let url: URL
    let isDirectory: Bool
    let byteCount: Int64
    var id: String { url.path }
    var name: String { url.lastPathComponent }
}

struct PackageRecord: Identifiable {
    let url: URL
    let byteCount: Int64
    let sha256: String
    let detectedFormat: String
    var id: String { url.path }
    var name: String { url.lastPathComponent }
}

struct ActivityRecord: Identifiable {
    let id = UUID()
    let title: String
    let detail: String
    let date = Date()
}

@MainActor
final class AppStore: ObservableObject {
    @Published private(set) var activities: [ActivityRecord] = []
    @Published private(set) var packages: [PackageRecord] = []

    private let fm = FileManager.default
    private let documents: URL
    let workspaceRoot: URL
    let packagesRoot: URL
    let exportsRoot: URL

    init() {
        documents = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        workspaceRoot = documents.appendingPathComponent("Workspace", isDirectory: true)
        packagesRoot = documents.appendingPathComponent("Packages", isDirectory: true)
        exportsRoot = documents.appendingPathComponent("Exports", isDirectory: true)
        createBaseFolders()
        refreshPackages()
        log("NOVAKIT is ready", detail: "Local workspace initialized")
    }

    private func createBaseFolders() {
        for url in [workspaceRoot, packagesRoot, exportsRoot,
                    workspaceRoot.appendingPathComponent("Patches", isDirectory: true),
                    workspaceRoot.appendingPathComponent("Imports", isDirectory: true),
                    workspaceRoot.appendingPathComponent("Notes", isDirectory: true)] {
            try? fm.createDirectory(at: url, withIntermediateDirectories: true)
        }
    }

    func log(_ title: String, detail: String) {
        activities.insert(ActivityRecord(title: title, detail: detail), at: 0)
        if activities.count > 30 { activities.removeLast(activities.count - 30) }
    }

    func workspaceURL(for relativePath: String = "") throws -> URL {
        let normalized = relativePath.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let candidate = normalized.isEmpty ? workspaceRoot : workspaceRoot.appendingPathComponent(normalized)
        let resolved = candidate.standardizedFileURL
        let rootPath = workspaceRoot.standardizedFileURL.path
        guard resolved.path == rootPath || resolved.path.hasPrefix(rootPath + "/") else {
            throw CocoaError(.fileReadInvalidFileName)
        }
        return resolved
    }

    func items(in relativePath: String = "") -> [WorkspaceItem] {
        guard let folder = try? workspaceURL(for: relativePath),
              let urls = try? fm.contentsOfDirectory(at: folder,
                                                     includingPropertiesForKeys: [.isDirectoryKey, .fileSizeKey],
                                                     options: [.skipsHiddenFiles]) else { return [] }
        return urls.map { url in
            let values = try? url.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey])
            return WorkspaceItem(url: url,
                                 isDirectory: values?.isDirectory ?? false,
                                 byteCount: Int64(values?.fileSize ?? 0))
        }.sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory }
            return $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
        }
    }

    func createFolder(named name: String, in relativePath: String) throws {
        let safeName = try sanitizedName(name)
        let parent = try workspaceURL(for: relativePath)
        let target = parent.appendingPathComponent(safeName, isDirectory: true)
        try fm.createDirectory(at: target, withIntermediateDirectories: false)
        log("Folder created", detail: safeName)
    }

    func createTextFile(named name: String, in relativePath: String) throws -> URL {
        var safeName = try sanitizedName(name)
        if URL(fileURLWithPath: safeName).pathExtension.isEmpty { safeName += ".txt" }
        let parent = try workspaceURL(for: relativePath)
        let target = uniqueURL(in: parent, name: safeName)
        try Data().write(to: target, options: .atomic)
        log("File created", detail: target.lastPathComponent)
        return target
    }

    func renameWorkspaceItem(_ item: WorkspaceItem, to newName: String) throws {
        let rootPath = workspaceRoot.standardizedFileURL.path
        guard item.url.standardizedFileURL.path.hasPrefix(rootPath + "/") else {
            throw CocoaError(.fileWriteNoPermission)
        }
        let safeName = try sanitizedName(newName)
        let destination = item.url.deletingLastPathComponent().appendingPathComponent(safeName)
        guard !fm.fileExists(atPath: destination.path) else {
            throw CocoaError(.fileWriteFileExists)
        }
        try fm.moveItem(at: item.url, to: destination)
        log("Item renamed", detail: "\(item.name) → \(safeName)")
    }

    func importWorkspaceFiles(_ urls: [URL], into relativePath: String) throws {
        let destination = try workspaceURL(for: relativePath)
        for source in urls {
            let access = source.startAccessingSecurityScopedResource()
            defer { if access { source.stopAccessingSecurityScopedResource() } }
            let name = try sanitizedName(source.lastPathComponent)
            let target = uniqueURL(in: destination, name: name)
            try fm.copyItem(at: source, to: target)
        }
        log("Files imported", detail: "\(urls.count) item(s) added to workspace")
    }

    func deleteWorkspaceItem(_ item: WorkspaceItem) throws {
        let rootPath = workspaceRoot.standardizedFileURL.path
        let path = item.url.standardizedFileURL.path
        guard path.hasPrefix(rootPath + "/") else { throw CocoaError(.fileWriteNoPermission) }
        try fm.removeItem(at: item.url)
        log("Item deleted", detail: item.name)
    }

    func readText(from url: URL) throws -> String {
        let rootPath = workspaceRoot.standardizedFileURL.path
        guard url.standardizedFileURL.path.hasPrefix(rootPath + "/") else {
            throw CocoaError(.fileReadNoPermission)
        }
        let data = try Data(contentsOf: url)
        guard let text = String(data: data, encoding: .utf8) else {
            throw CocoaError(.fileReadCorruptFile)
        }
        return text
    }

    func saveText(_ text: String, to url: URL) throws {
        let rootPath = workspaceRoot.standardizedFileURL.path
        guard url.standardizedFileURL.path.hasPrefix(rootPath + "/") else {
            throw CocoaError(.fileWriteNoPermission)
        }
        try Data(text.utf8).write(to: url, options: .atomic)
        log("File saved", detail: url.lastPathComponent)
    }

    func importPackages(_ urls: [URL]) throws {
        for source in urls {
            let access = source.startAccessingSecurityScopedResource()
            defer { if access { source.stopAccessingSecurityScopedResource() } }
            let name = try sanitizedName(source.lastPathComponent)
            let target = uniqueURL(in: packagesRoot, name: name)
            try fm.copyItem(at: source, to: target)
        }
        refreshPackages()
        log("Packages imported", detail: "\(urls.count) package(s) stored locally")
    }

    func exportPatch(name: String, bundleID: String, path: String, text: String, note: String) throws -> URL {
        let data = try PatchPackageBuilder.make(name: name, bundleID: bundleID,
                                                relativePath: path, text: text, note: note)
        let base = try sanitizedName(name).replacingOccurrences(of: ".", with: "-")
        let target = uniqueURL(in: exportsRoot, name: base + ".novapatch")
        try data.write(to: target, options: .atomic)
        refreshPackages()
        log("Patch package created", detail: target.lastPathComponent)
        return target
    }

    func refreshPackages() {
        let packageURLs = (try? fm.contentsOfDirectory(at: packagesRoot,
                                                        includingPropertiesForKeys: [.fileSizeKey],
                                                        options: [.skipsHiddenFiles])) ?? []
        let exportURLs = (try? fm.contentsOfDirectory(at: exportsRoot,
                                                       includingPropertiesForKeys: [.fileSizeKey],
                                                       options: [.skipsHiddenFiles])) ?? []
        let urls = packageURLs + exportURLs
        packages = urls.compactMap { url in
            guard let data = try? Data(contentsOf: url) else { return nil }
            let sizeValue = (try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize ?? data.count
            let size = Int64(sizeValue)
            return PackageRecord(url: url, byteCount: size,
                                 sha256: SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined(),
                                 detectedFormat: Self.detectFormat(data: data, ext: url.pathExtension))
        }.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }

    func deletePackage(_ package: PackageRecord) throws {
        let path = package.url.standardizedFileURL.path
        let packagePath = packagesRoot.standardizedFileURL.path
        let exportPath = exportsRoot.standardizedFileURL.path
        guard path.hasPrefix(packagePath + "/") || path.hasPrefix(exportPath + "/") else {
            throw CocoaError(.fileWriteNoPermission)
        }
        try fm.removeItem(at: package.url)
        refreshPackages()
        log("Package deleted", detail: package.name)
    }

    static func detectFormat(data: Data, ext: String) -> String {
        if data.starts(with: [0x50, 0x4B, 0x03, 0x04]) { return "ZIP archive" }
        if data.starts(with: Array("bplist00".utf8)) { return "Binary property list" }
        let trimmed = data.prefix(64).drop(while: { [0x09, 0x0A, 0x0D, 0x20].contains($0) })
        if trimmed.starts(with: [0x7B, 0x22]) || trimmed.starts(with: [0x5B]) { return "JSON / text data" }
        if String(data: data.prefix(128), encoding: .utf8)?.contains("<?xml") == true { return "XML / plist text" }
        if ["3105", "1411"].contains(ext.lowercased()) { return "Opaque patch package (not decoded)" }
        return "Unknown binary / data"
    }

    private func sanitizedName(_ name: String) throws -> String {
        let value = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty, value != ".", value != "..",
              !value.contains("/"), !value.contains("\\") else {
            throw CocoaError(.fileReadInvalidFileName)
        }
        return value
    }

    private func uniqueURL(in folder: URL, name: String) -> URL {
        let original = URL(fileURLWithPath: name)
        let ext = original.pathExtension
        let stem = original.deletingPathExtension().lastPathComponent
        var candidate = folder.appendingPathComponent(name)
        var index = 2
        while fm.fileExists(atPath: candidate.path) {
            let next = ext.isEmpty ? "\(stem) \(index)" : "\(stem) \(index).\(ext)"
            candidate = folder.appendingPathComponent(next)
            index += 1
        }
        return candidate
    }
}
