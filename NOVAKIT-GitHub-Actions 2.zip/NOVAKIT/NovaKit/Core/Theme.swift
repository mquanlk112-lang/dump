import SwiftUI
import UIKit

// NOVAKIT design system: dark graphite surfaces with violet/cyan highlights.
enum NKTheme {
    static let background = Color(red: 0.035, green: 0.043, blue: 0.075)
    static let surface = Color(red: 0.075, green: 0.086, blue: 0.135)
    static let surfaceRaised = Color(red: 0.105, green: 0.117, blue: 0.175)
    static let line = Color.white.opacity(0.09)
    static let muted = Color(red: 0.57, green: 0.61, blue: 0.71)
    static let violet = Color(red: 0.55, green: 0.38, blue: 1.0)
    static let cyan = Color(red: 0.20, green: 0.82, blue: 0.91)
    static let green = Color(red: 0.25, green: 0.82, blue: 0.61)
    static let orange = Color(red: 1.0, green: 0.66, blue: 0.31)
    static let danger = Color(red: 1.0, green: 0.36, blue: 0.42)

    static let heroGradient = LinearGradient(
        colors: [violet.opacity(0.95), Color(red: 0.30, green: 0.30, blue: 0.88), cyan.opacity(0.85)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
}

struct NKCard<Content: View>: View {
    var padding: CGFloat
    let content: Content

    init(padding: CGFloat = 16, @ViewBuilder content: () -> Content) {
        self.padding = padding
        self.content = content()
    }

    var body: some View {
        content
            .padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background {
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .fill(NKTheme.surface.opacity(0.96))
                    .overlay {
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .stroke(NKTheme.line, lineWidth: 1)
                    }
            }
    }
}

struct NKSectionTitle: View {
    let title: String
    var subtitle: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.system(size: 19, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            if let subtitle {
                Text(subtitle)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(NKTheme.muted)
            }
        }
    }
}

struct NKTag: View {
    let title: String
    var color: Color = NKTheme.cyan

    var body: some View {
        Text(title.uppercased())
            .font(.system(size: 9, weight: .heavy, design: .rounded))
            .tracking(0.8)
            .foregroundStyle(color)
            .padding(.horizontal, 9)
            .padding(.vertical, 6)
            .background(color.opacity(0.13), in: Capsule())
    }
}

struct NKBackground: View {
    var body: some View {
        ZStack(alignment: .topTrailing) {
            NKTheme.background.ignoresSafeArea()
            Circle()
                .fill(NKTheme.violet.opacity(0.12))
                .frame(width: 250, height: 250)
                .blur(radius: 80)
                .offset(x: 100, y: -90)
            Circle()
                .fill(NKTheme.cyan.opacity(0.07))
                .frame(width: 220, height: 220)
                .blur(radius: 80)
                .offset(x: -180, y: 400)
        }
        .ignoresSafeArea()
    }
}

extension View {
    func nkScreen() -> some View {
        background(NKBackground())
    }
}


/// iOS 15-compatible replacement for SwiftUI ShareLink (introduced in iOS 16).
struct NKShareButton<LabelContent: View>: View {
    let url: URL
    private let labelContent: LabelContent
    @State private var isPresented = false

    init(url: URL, @ViewBuilder label: () -> LabelContent) {
        self.url = url
        self.labelContent = label()
    }

    var body: some View {
        Button { isPresented = true } label: { labelContent }
            .sheet(isPresented: $isPresented) {
                NKActivityViewController(activityItems: [url])
            }
    }
}

struct NKActivityViewController: UIViewControllerRepresentable {
    let activityItems: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
