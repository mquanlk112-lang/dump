import SwiftUI
import UniformTypeIdentifiers

struct WorkspaceView: View {
    @EnvironmentObject private var store: AppStore
    @State private var folders: [String] = []
    @State private var showingImporter = false
    @State private var showingExternalBrowser = false
    @State private var showingCreate = false
    @State private var selectedEditor: EditorPayload?
    @State private var renamingItem: WorkspaceItem?
    @State private var errorMessage: String?
    @State private var selectionMode = "Workspace"

    private var relativePath: String {
        if selectionMode == "Workspace" { return folders.joined(separator: "/") }
        return ([selectionMode] + folders).joined(separator: "/")
    }

    private var items: [WorkspaceItem] { store.items(in: relativePath) }

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                pathHeader
                if items.isEmpty {
                    emptyFolder
                } else {
                    List {
                        ForEach(items) { item in
                            workspaceRow(item)
                                .listRowBackground(Color.clear)
                                .listRowSeparatorTint(NKTheme.line)
                        }
                        .onDelete(perform: deleteItems)
                    }
                    .listStyle(.plain)
                        }
            }
            .nkScreen()
            .navigationTitle("Workspace")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Menu {
                        Button { selectionMode = "Workspace"; folders = [] } label: { Label("Workspace", systemImage: "folder") }
                        Button { selectionMode = "Patches"; folders = [] } label: { Label("Patches", systemImage: "wrench.and.screwdriver") }
                        Button { selectionMode = "Imports"; folders = [] } label: { Label("Imports", systemImage: "square.and.arrow.down") }
                        Button { selectionMode = "Notes"; folders = [] } label: { Label("Notes", systemImage: "note.text") }
                    } label: {
                        Image(systemName: "line.3.horizontal.decrease.circle")
                    }
                }
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button { showingExternalBrowser = true } label: { Image(systemName: "folder") }
                    Button { showingImporter = true } label: { Image(systemName: "square.and.arrow.down") }
                    Menu {
                        Button("Browse folders in Files", systemImage: "folder") { showingExternalBrowser = true }
                        Button("New folder", systemImage: "folder.badge.plus") { showingCreate = true }
                        Button("New text file", systemImage: "doc.badge.plus") { createTextFile() }
                    } label: {
                        Image(systemName: "plus.circle.fill")
                    }
                }
            }
            .fileImporter(isPresented: $showingImporter,
                          allowedContentTypes: [.item],
                          allowsMultipleSelection: true) { result in
                do {
                    try store.importWorkspaceFiles(result.get(), into: relativePath)
                } catch {
                    errorMessage = error.localizedDescription
                }
            }
            .sheet(isPresented: $showingExternalBrowser) {
                ExternalFilesView()
            }
            .sheet(isPresented: $showingCreate) {
                NameEntrySheet(title: "Create folder", placeholder: "Folder name", buttonTitle: "Create") { name in
                    do { try store.createFolder(named: name, in: relativePath) }
                    catch { errorMessage = error.localizedDescription }
                }
            }
            .sheet(item: $selectedEditor) { payload in
                TextEditorSheet(payload: payload) { newText in
                    do { try store.saveText(newText, to: payload.url) }
                    catch { errorMessage = error.localizedDescription }
                }
            }
            .sheet(item: $renamingItem) { item in
                NameEntrySheet(title: "Rename item", placeholder: item.name, buttonTitle: "Save", initialValue: item.name) { name in
                    do { try store.renameWorkspaceItem(item, to: name) }
                    catch { errorMessage = error.localizedDescription }
                }
            }
            .alert("Workspace", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("OK", role: .cancel) { errorMessage = nil }
            } message: {
                Text(errorMessage ?? "Unknown error")
            }
        }
    }

    private var pathHeader: some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(selectionMode.uppercased())
                        .font(.system(size: 9, weight: .heavy, design: .rounded))
                        .tracking(1.5)
                        .foregroundStyle(NKTheme.cyan)
                    Text(folders.isEmpty ? "Root folder" : folders.joined(separator: " / "))
                        .font(.system(size: 17, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                }
                Spacer()
                Text("\(items.count) ITEMS")
                    .font(.system(size: 9, weight: .heavy, design: .rounded))
                    .foregroundStyle(NKTheme.muted)
            }
            if !folders.isEmpty {
                Button {
                    folders.removeLast()
                } label: {
                    Label("Back one folder", systemImage: "arrow.left")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundStyle(NKTheme.cyan)
                }
            }
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 13)
    }

    private var emptyFolder: some View {
        VStack(spacing: 12) {
            Spacer()
            Image(systemName: "folder.badge.plus")
                .font(.system(size: 34, weight: .light))
                .foregroundStyle(NKTheme.muted)
            Text("This folder is empty")
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(.white)
            Text("Create a folder or import files to this workspace.")
                .font(.system(size: 11))
                .foregroundStyle(NKTheme.muted)
                .multilineTextAlignment(.center)
            Button { showingImporter = true } label: {
                Label("Import files", systemImage: "square.and.arrow.down")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(NKTheme.background)
                    .padding(.horizontal, 17)
                    .padding(.vertical, 11)
                    .background(NKTheme.cyan, in: Capsule())
            }
            Spacer()
        }
        .frame(maxWidth: .infinity)
        .padding(25)
    }

    private func workspaceRow(_ item: WorkspaceItem) -> some View {
        HStack(spacing: 11) {
            RoundedRectangle(cornerRadius: 10)
                .fill(item.isDirectory ? NKTheme.violet.opacity(0.15) : NKTheme.cyan.opacity(0.12))
                .frame(width: 37, height: 37)
                .overlay(Image(systemName: item.isDirectory ? "folder.fill" : fileIcon(item.name))
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(item.isDirectory ? NKTheme.violet : NKTheme.cyan))
            VStack(alignment: .leading, spacing: 3) {
                Text(item.name)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(item.isDirectory ? "Folder" : ByteCountFormatter.string(fromByteCount: item.byteCount, countStyle: .file))
                    .font(.system(size: 9, weight: .medium))
                    .foregroundStyle(NKTheme.muted)
            }
            Spacer()
            Menu {
                if !item.isDirectory && isTextFile(item.name) {
                    Button("Edit text", systemImage: "pencil") { openEditor(item) }
                }
                Button("Rename", systemImage: "pencil.line") { renamingItem = item }
                if !item.isDirectory {
                    NKShareButton(url: item.url) {
                        Label("Share / export", systemImage: "square.and.arrow.up")
                    }
                }
                Button("Delete", systemImage: "trash", role: .destructive) {
                    do { try store.deleteWorkspaceItem(item) }
                    catch { errorMessage = error.localizedDescription }
                }
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(NKTheme.muted)
                    .frame(width: 34, height: 34)
            }
            if item.isDirectory {
                Button { folders.append(item.name) } label: {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundStyle(NKTheme.muted)
                        .padding(.leading, 5)
                }
            }
        }
        .padding(.vertical, 4)
        .contentShape(Rectangle())
        .onTapGesture {
            if item.isDirectory { folders.append(item.name) }
            else if isTextFile(item.name) { openEditor(item) }
        }
    }

    private func fileIcon(_ name: String) -> String {
        let ext = URL(fileURLWithPath: name).pathExtension.lowercased()
        switch ext {
        case "json": return "curlybraces"
        case "plist", "xml": return "list.bullet.rectangle"
        case "png", "jpg", "jpeg", "heic": return "photo"
        case "zip", "ipa": return "archivebox"
        case "novapatch", "3105", "1411": return "shippingbox"
        default: return "doc.text"
        }
    }

    private func isTextFile(_ name: String) -> Bool {
        ["txt", "md", "json", "plist", "xml", "strings", "csv", "log", "html", "css", "js"].contains(URL(fileURLWithPath: name).pathExtension.lowercased())
    }

    private func openEditor(_ item: WorkspaceItem) {
        do {
            let text = try store.readText(from: item.url)
            selectedEditor = EditorPayload(url: item.url, initialText: text)
        } catch {
            errorMessage = "This file is not readable as UTF-8 text."
        }
    }

    private func createTextFile() {
        do {
            let url = try store.createTextFile(named: "New Note.txt", in: relativePath)
            selectedEditor = EditorPayload(url: url, initialText: "")
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func deleteItems(at offsets: IndexSet) {
        for index in offsets {
            do { try store.deleteWorkspaceItem(items[index]) }
            catch { errorMessage = error.localizedDescription }
        }
    }
}

struct EditorPayload: Identifiable {
    let id = UUID()
    let url: URL
    let initialText: String
}

struct TextEditorSheet: View {
    @Environment(\.dismiss) private var dismiss
    let payload: EditorPayload
    let onSave: (String) -> Void
    @State private var text: String

    init(payload: EditorPayload, onSave: @escaping (String) -> Void) {
        self.payload = payload
        self.onSave = onSave
        _text = State(initialValue: payload.initialText)
    }

    var body: some View {
        NavigationView {
            TextEditor(text: $text)
                .font(.system(size: 12, design: .monospaced))
                    .padding(12)
                .background(NKTheme.background)
                .foregroundStyle(.white)
                .navigationTitle(payload.url.lastPathComponent)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) { Button("Cancel") { dismiss() } }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("Save") { onSave(text); dismiss() }
                            .fontWeight(.bold)
                    }
                }
                .nkScreen()
        }
        .preferredColorScheme(.dark)
    }
}

struct NameEntrySheet: View {
    @Environment(\.dismiss) private var dismiss
    let title: String
    let placeholder: String
    let buttonTitle: String
    var initialValue: String = ""
    let onCommit: (String) -> Void
    @State private var value: String

    init(title: String, placeholder: String, buttonTitle: String, initialValue: String = "", onCommit: @escaping (String) -> Void) {
        self.title = title
        self.placeholder = placeholder
        self.buttonTitle = buttonTitle
        self.initialValue = initialValue
        self.onCommit = onCommit
        _value = State(initialValue: initialValue)
    }

    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 16) {
                TextField(placeholder, text: $value)
                    .font(.system(size: 14, weight: .medium))
                    .padding(14)
                    .background(NKTheme.surfaceRaised, in: RoundedRectangle(cornerRadius: 13))
                Button {
                    onCommit(value)
                    dismiss()
                } label: {
                    Text(buttonTitle)
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(NKTheme.background)
                        .frame(maxWidth: .infinity)
                        .padding(13)
                        .background(NKTheme.cyan, in: RoundedRectangle(cornerRadius: 13))
                }
                .disabled(value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                Spacer(minLength: 0)
            }
            .padding(18)
            .nkScreen()
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) { Button("Cancel") { dismiss() } }
            }
        }
        .preferredColorScheme(.dark)
    }
}
