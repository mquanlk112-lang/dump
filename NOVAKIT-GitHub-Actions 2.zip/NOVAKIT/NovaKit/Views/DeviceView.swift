import SwiftUI
import UIKit

struct DeviceView: View {
    @AppStorage("novakit.compactMode") private var compactMode = false
    @AppStorage("novakit.haptics") private var hapticsEnabled = true

    private var deviceName: String { UIDevice.current.name }
    private var deviceModel: String { UIDevice.current.model }
    private var systemVersion: String { UIDevice.current.systemVersion }

    var body: some View {
        NavigationView {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    deviceHero
                    VStack(alignment: .leading, spacing: 10) {
                        NKSectionTitle(title: "System information", subtitle: "Read-only values provided by iOS")
                        detailRow("Device name", value: deviceName, icon: "iphone")
                        detailRow("Device type", value: deviceModel, icon: "cpu")
                        detailRow("iOS version", value: systemVersion, icon: "gearshape.2")
                        detailRow("Application", value: "NOVAKIT 1.1 (2)", icon: "app.badge")
                        detailRow("Storage mode", value: "Sandbox + user-selected folders", icon: "lock.shield")
                    }
                    preferences
                    privacyNote
                }
                .padding(18)
                .padding(.bottom, 24)
            }
            .nkScreen()
            .navigationTitle("Device")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink(destination: SettingsView()) {
                        Image(systemName: "gearshape.fill")
                    }
                }
            }
        }
    }

    private var deviceHero: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 24)
                .fill(NKTheme.heroGradient)
            HStack(spacing: 15) {
                ZStack {
                    RoundedRectangle(cornerRadius: 17)
                        .fill(.white.opacity(0.17))
                        .frame(width: 60, height: 60)
                    Image(systemName: "iphone")
                        .font(.system(size: 28, weight: .medium))
                        .foregroundStyle(.white)
                }
                VStack(alignment: .leading, spacing: 5) {
                    Text("CONNECTED DEVICE")
                        .font(.system(size: 9, weight: .heavy, design: .rounded))
                        .tracking(1.3)
                        .foregroundStyle(.white.opacity(0.75))
                    Text(deviceName)
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                    Text("iOS \(systemVersion)")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.82))
                }
                Spacer(minLength: 0)
            }
            .padding(18)
        }
        .frame(height: 112)
    }

    private func detailRow(_ title: String, value: String, icon: String) -> some View {
        NKCard(padding: 13) {
            HStack(spacing: 10) {
                Image(systemName: icon)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(NKTheme.cyan)
                    .frame(width: 30, height: 30)
                    .background(NKTheme.cyan.opacity(0.12), in: RoundedRectangle(cornerRadius: 9))
                Text(title)
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(NKTheme.muted)
                Spacer()
                Text(value)
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.trailing)
            }
        }
    }

    private var preferences: some View {
        VStack(alignment: .leading, spacing: 10) {
            NKSectionTitle(title: "Preferences", subtitle: "Stored locally on this device")
            NKCard(padding: 4) {
                Toggle(isOn: $compactMode) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Compact layout").font(.system(size: 12, weight: .semibold)).foregroundStyle(.white)
                        Text("Reduce spacing in lists").font(.system(size: 9)).foregroundStyle(NKTheme.muted)
                    }
                }
                .tint(NKTheme.cyan)
                .padding(10)
                Rectangle().fill(NKTheme.line).frame(height: 1).padding(.leading, 10)
                Toggle(isOn: $hapticsEnabled) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Haptic feedback").font(.system(size: 12, weight: .semibold)).foregroundStyle(.white)
                        Text("Preference stored for future interactions").font(.system(size: 9)).foregroundStyle(NKTheme.muted)
                    }
                }
                .tint(NKTheme.cyan)
                .padding(10)
            }
        }
    }

    private var privacyNote: some View {
        HStack(alignment: .top, spacing: 9) {
            Image(systemName: "lock.fill").foregroundStyle(NKTheme.green)
            Text("This screen reads standard iOS device properties only. File access is limited to NOVAKIT’s sandbox and folders explicitly selected by the user in Files.")
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(NKTheme.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}
