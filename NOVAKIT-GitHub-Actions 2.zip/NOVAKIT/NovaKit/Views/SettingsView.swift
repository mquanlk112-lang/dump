import SwiftUI

struct SettingsView: View {
    @AppStorage("novakit.compactMode") private var compactMode = false
    @AppStorage("novakit.haptics") private var hapticsEnabled = true

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                sectionTitle("Appearance", subtitle: "Personalize the workspace")
                NKCard(padding: 14) {
                    Toggle("Compact layout", isOn: $compactMode)
                        .tint(NKTheme.cyan)
                    Divider().overlay(NKTheme.line).padding(.vertical, 5)
                    Toggle("Haptic feedback preference", isOn: $hapticsEnabled)
                        .tint(NKTheme.cyan)
                }

                sectionTitle("About NOVAKIT", subtitle: "Application information")
                NKCard(padding: 14) {
                    infoRow("Version", value: "1.1 (2)")
                    Divider().overlay(NKTheme.line).padding(.vertical, 5)
                    infoRow("Bundle", value: "com.minhquandev.novakit")
                    Divider().overlay(NKTheme.line).padding(.vertical, 5)
                    infoRow("Storage", value: "App sandbox + user-selected folders")
                    Divider().overlay(NKTheme.line).padding(.vertical, 9)
                    Link(destination: URL(string: "https://t.me/toibivosinh")!) {
                        HStack(spacing: 9) {
                            Image(systemName: "paperplane.fill")
                                .foregroundStyle(NKTheme.cyan)
                            VStack(alignment: .leading, spacing: 3) {
                                Text("Developed by")
                                    .font(.system(size: 10, weight: .medium))
                                    .foregroundStyle(NKTheme.muted)
                                Text("t.me/toibivosinh")
                                    .font(.system(size: 12, weight: .bold))
                                    .foregroundStyle(NKTheme.cyan)
                            }
                            Spacer()
                            Image(systemName: "arrow.up.right")
                                .font(.system(size: 10, weight: .bold))
                                .foregroundStyle(NKTheme.muted)
                        }
                    }
                }

                NKCard(padding: 14) {
                    Label("File access is limited to NOVAKIT's container and folders or files explicitly selected by the user in Files.", systemImage: "lock.shield.fill")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(NKTheme.muted)
                        .fixedSize(horizontal: false, vertical: true)
                    Text("NOVAKIT cannot browse another app's private container or apply third-party game patches.")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(NKTheme.muted)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(.top, 7)
                }
            }
            .padding(18)
            .padding(.bottom, 24)
        }
        .nkScreen()
        .preferredColorScheme(.dark)
        .navigationTitle("Settings")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func sectionTitle(_ title: String, subtitle: String) -> some View {
        NKSectionTitle(title: title, subtitle: subtitle)
    }

    private func infoRow(_ title: String, value: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Text(title)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(NKTheme.muted)
            Spacer(minLength: 8)
            Text(value)
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(.white)
                .multilineTextAlignment(.trailing)
        }
    }
}
