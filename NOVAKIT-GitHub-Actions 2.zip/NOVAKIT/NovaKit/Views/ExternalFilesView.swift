import SwiftUI
import UniformTypeIdentifiers
import CryptoKit

private struct ExternalFileEntry: Identifiable {
    let url: URL
    let isDirectory: Bool
    let byteCount: Int64
    let modified: Date?
    var id: String { url.path }
    var name: String { url.lastPathComponent }
}

/// Browses only a directory explicitly granted by the user through the iOS Files document picker.
struct ExternalFilesView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var selectedRoot: URL?
    @State private var isAccessing = false
    @State private var showingImporter = false
    @State private var errorMessage: String?
    @State private var didAttemptRestore = false
    private let bookmarkKey = "novakit.externalFolder.bookmark"

    var body: some View {
        NavigationView {
            Group {
                if let root = selectedRoot {
                    ExternalFolderContentsView(rootURL: root, folderURL: root)
                } else {
                    emptyState
                }
            }
            .navigationTitle("Files Access")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Close") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(selectedRoot == nil ? "Choose" : "Change") {
                        showingImporter = true
                    }
                }
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .fileImporter(isPresented: $showingImporter,
                      allowedContentTypes: [.folder],
                      allowsMultipleSelection: false) { result in
            handleFolderSelection(result)
        }
        .alert("Files Access", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "Unable to access this folder.")
        }
        .onAppear { restoreSavedFolderIfNeeded() }
        .onDisappear { releaseFolderAccess() }
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "folder.badge.plus")
                .font(.system(size: 48, weight: .light))
                .foregroundStyle(NKTheme.cyan)
            Text("Choose a folder from Files")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Text("NOVAKIT can browse the folder and its subfolders after you grant access. The folder remains in its original location; this browser does not copy or modify its contents.")
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(NKTheme.muted)
                .multilineTextAlignment(.center)
                .lineSpacing(3)
                .padding(.horizontal, 25)
            Button { showingImporter = true } label: {
                Label("Select folder", systemImage: "folder")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(NKTheme.background)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 12)
                    .background(NKTheme.cyan, in: Capsule())
            }
            Text("Access is limited to the folder you select.")
                .font(.system(size: 9, weight: .medium))
                .foregroundStyle(NKTheme.muted)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .nkScreen()
    }

    private func handleFolderSelection(_ result: Result<[URL], Error>) {
        do {
            guard let url = try result.get().first else {
                errorMessage = "No folder was selected."
                return
            }
            releaseFolderAccess()
            guard url.startAccessingSecurityScopedResource() else {
                errorMessage = "iOS did not grant access to this folder. Select it again in Files or choose a folder stored locally/iCloud Drive."
                return
            }
            isAccessing = true
            selectedRoot = url
            saveBookmark(for: url)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func restoreSavedFolderIfNeeded() {
        guard !didAttemptRestore else { return }
        didAttemptRestore = true
        guard let data = UserDefaults.standard.data(forKey: bookmarkKey) else { return }
        do {
            var isStale = false
            let url = try URL(resolvingBookmarkData: data, bookmarkDataIsStale: &isStale)
            guard url.startAccessingSecurityScopedResource() else {
                errorMessage = "Access to the previously selected folder is no longer available. Select it again in Files."
                UserDefaults.standard.removeObject(forKey: bookmarkKey)
                return
            }
            isAccessing = true
            selectedRoot = url
            if isStale { saveBookmark(for: url) }
        } catch {
            UserDefaults.standard.removeObject(forKey: bookmarkKey)
            errorMessage = "The saved folder permission expired. Select the folder again in Files."
        }
    }

    private func saveBookmark(for url: URL) {
        do {
            let data = try url.bookmarkData(options: .minimalBookmark,
                                            includingResourceValuesForKeys: nil,
                                            relativeTo: nil)
            UserDefaults.standard.set(data, forKey: bookmarkKey)
        } catch {
            errorMessage = "Folder access works for this session, but iOS could not save its permission for next time: \(error.localizedDescription)"
        }
    }

    private func releaseFolderAccess() {
        if isAccessing, let selectedRoot {
            selectedRoot.stopAccessingSecurityScopedResource()
        }
        isAccessing = false
        selectedRoot = nil
    }
}

private struct ExternalFolderContentsView: View {
    let rootURL: URL
    let folderURL: URL
    private let fileManager = FileManager.default
    @State private var hasFolderAccess = false

    private var entries: [ExternalFileEntry] {
        guard isInsideGrantedRoot(folderURL),
              folderURL.startAccessingSecurityScopedResource() else { return [] }
        defer { folderURL.stopAccessingSecurityScopedResource() }
        guard let urls = try? ExternalFileCoordinator.read(at: folderURL, operation: { coordinatedURL in
                  try fileManager.contentsOfDirectory(
                    at: coordinatedURL,
                    includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey, .fileSizeKey, .contentModificationDateKey],
                    options: [.skipsHiddenFiles]
                  )
              }) else { return [] }

        return urls.compactMap { url in
            guard isInsideGrantedRoot(url), url.startAccessingSecurityScopedResource() else { return nil }
            defer { url.stopAccessingSecurityScopedResource() }
            guard let values = try? url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey, .fileSizeKey, .contentModificationDateKey]),
                  values.isSymbolicLink != true else { return nil }
            return ExternalFileEntry(url: url,
                                     isDirectory: values.isDirectory ?? false,
                                     byteCount: Int64(values.fileSize ?? 0),
                                     modified: values.contentModificationDate)
        }.sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory }
            return $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
        }
    }

    var body: some View {
        List {
            Section {
                HStack(spacing: 8) {
                    Image(systemName: "lock.fill").foregroundStyle(NKTheme.green)
                    Text("Read access granted by Files")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundStyle(NKTheme.muted)
                }
                .listRowBackground(Color.clear)
            }

            if entries.isEmpty {
                Text("No visible items in this folder.")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(NKTheme.muted)
                    .listRowBackground(Color.clear)
            } else {
                Section("\(entries.count) items") {
                    ForEach(entries) { entry in
                        if entry.isDirectory {
                            NavigationLink(destination: ExternalFolderContentsView(rootURL: rootURL, folderURL: entry.url)) {
                                ExternalEntryRow(entry: entry)
                            }
                        } else {
                            NavigationLink(destination: ExternalFileDetailView(entry: entry)) {
                                ExternalEntryRow(entry: entry)
                            }
                        }
                    }
                }
            }
        }
        .listStyle(.plain)
        .nkScreen()
        .navigationTitle(folderURL.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { hasFolderAccess = folderURL.startAccessingSecurityScopedResource() }
        .onDisappear {
            if hasFolderAccess { folderURL.stopAccessingSecurityScopedResource() }
            hasFolderAccess = false
        }
    }

    private func isInsideGrantedRoot(_ candidate: URL) -> Bool {
        let rootPath = rootURL.standardizedFileURL.resolvingSymlinksInPath().path
        let candidatePath = candidate.standardizedFileURL.resolvingSymlinksInPath().path
        return candidatePath == rootPath || candidatePath.hasPrefix(rootPath + "/")
    }
}

private struct ExternalEntryRow: View {
    let entry: ExternalFileEntry

    var body: some View {
        HStack(spacing: 11) {
            RoundedRectangle(cornerRadius: 10)
                .fill(entry.isDirectory ? NKTheme.violet.opacity(0.15) : NKTheme.cyan.opacity(0.12))
                .frame(width: 37, height: 37)
                .overlay {
                    Image(systemName: entry.isDirectory ? "folder.fill" : iconName)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(entry.isDirectory ? NKTheme.violet : NKTheme.cyan)
                }
            VStack(alignment: .leading, spacing: 3) {
                Text(entry.name)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(entry.isDirectory ? "Folder" : ByteCountFormatter.string(fromByteCount: entry.byteCount, countStyle: .file))
                    .font(.system(size: 9, weight: .medium))
                    .foregroundStyle(NKTheme.muted)
            }
            Spacer()
            if let modified = entry.modified {
                Text(modified, style: .date)
                    .font(.system(size: 8, weight: .medium))
                    .foregroundStyle(NKTheme.muted)
            }
        }
        .padding(.vertical, 3)
        .listRowBackground(Color.clear)
    }

    private var iconName: String {
        switch entry.url.pathExtension.lowercased() {
        case "json": return "curlybraces"
        case "plist", "xml": return "list.bullet.rectangle"
        case "png", "jpg", "jpeg", "heic": return "photo"
        case "zip", "ipa": return "archivebox"
        case "3105", "1411": return "shippingbox"
        case "txt", "md", "log", "csv": return "doc.text"
        default: return "doc"
        }
    }
}

private struct ExternalFileDetailView: View {
    let entry: ExternalFileEntry
    @State private var fileSize = "—"
    @State private var modified = "—"
    @State private var sha256 = "Calculating…"
    @State private var textContent: String?
    @State private var hexContent: String?
    @State private var statusMessage: String?
    @State private var loadError: String?
    @State private var hasFileAccess = false

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                NKCard {
                    VStack(alignment: .leading, spacing: 10) {
                        Label("FILE DETAILS", systemImage: "doc.text")
                            .font(.system(size: 10, weight: .heavy, design: .rounded))
                            .tracking(1)
                            .foregroundStyle(NKTheme.cyan)
                        detailRow("Name", value: entry.name)
                        detailRow("Size", value: fileSize)
                        detailRow("Modified", value: modified)
                        detailRow("SHA-256", value: sha256)
                        Text(entry.url.path)
                            .font(.system(size: 9, design: .monospaced))
                            .foregroundStyle(NKTheme.muted)
                            .textSelection(.enabled)
                    }
                }

                if let textContent {
                    VStack(alignment: .leading, spacing: 8) {
                        NKSectionTitle(title: "File contents", subtitle: "UTF-8 text · read-only")
                        Text(textContent)
                            .font(.system(size: 10, design: .monospaced))
                            .foregroundStyle(.white.opacity(0.92))
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(12)
                            .background(NKTheme.surface, in: RoundedRectangle(cornerRadius: 14))
                    }
                } else if let hexContent {
                    VStack(alignment: .leading, spacing: 8) {
                        NKSectionTitle(title: "Binary preview", subtitle: "First 256 bytes · hexadecimal")
                        Text(hexContent)
                            .font(.system(size: 9, design: .monospaced))
                            .foregroundStyle(NKTheme.cyan)
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(12)
                            .background(NKTheme.surface, in: RoundedRectangle(cornerRadius: 14))
                    }
                }

                if let statusMessage {
                    Text(statusMessage)
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(NKTheme.orange)
                }
                if let loadError {
                    Text(loadError)
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(NKTheme.danger)
                }
                NKShareButton(url: entry.url) {
                    Label("Share / export original file", systemImage: "square.and.arrow.up")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(NKTheme.background)
                        .frame(maxWidth: .infinity)
                        .padding(13)
                        .background(NKTheme.cyan, in: RoundedRectangle(cornerRadius: 13))
                }
            }
            .padding(16)
            .padding(.bottom, 25)
        }
        .nkScreen()
        .navigationTitle(entry.name)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            hasFileAccess = entry.url.startAccessingSecurityScopedResource()
            loadFileDetails()
        }
        .onDisappear {
            if hasFileAccess { entry.url.stopAccessingSecurityScopedResource() }
            hasFileAccess = false
        }
    }

    private func detailRow(_ title: String, value: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Text(title).foregroundStyle(NKTheme.muted)
            Spacer(minLength: 6)
            Text(value)
                .foregroundStyle(.white)
                .multilineTextAlignment(.trailing)
                .textSelection(.enabled)
        }
        .font(.system(size: 10, weight: .medium, design: .monospaced))
    }

    private func loadFileDetails() {
        do {
            guard hasFileAccess else {
                throw CocoaError(.fileReadNoPermission)
            }
            let values = try entry.url.resourceValues(forKeys: [.fileSizeKey, .contentModificationDateKey])
            fileSize = ByteCountFormatter.string(fromByteCount: Int64(values.fileSize ?? 0), countStyle: .file)
            if let date = values.contentModificationDate {
                modified = DateFormatter.localizedString(from: date, dateStyle: .medium, timeStyle: .short)
            }

            sha256 = try Self.calculateSHA256(url: entry.url)
            let size = values.fileSize ?? 0
            let previewLimit = 8 * 1024 * 1024
            guard size <= previewLimit else {
                statusMessage = "This file is larger than 8 MB. Its full SHA-256 was calculated; use Share / export to open the original file in a compatible viewer."
                return
            }

            let data = try ExternalFileCoordinator.read(at: entry.url) { coordinatedURL in
                try Data(contentsOf: coordinatedURL, options: .mappedIfSafe)
            }
            if let decoded = String(data: data, encoding: .utf8) {
                textContent = decoded.isEmpty ? "(empty file)" : decoded
            } else {
                hexContent = data.prefix(256).enumerated().map { index, byte in
                    String(format: "%04X  %02X", index, byte)
                }.joined(separator: "\n")
                if data.count > 256 { statusMessage = "Binary preview is limited to the first 256 bytes. The original file remains available through Share / export." }
            }
        } catch {
            loadError = "Unable to read this file: \(error.localizedDescription)"
        }
    }

    private static func calculateSHA256(url: URL) throws -> String {
        try ExternalFileCoordinator.read(at: url) { coordinatedURL in
            let handle = try FileHandle(forReadingFrom: coordinatedURL)
            defer { try? handle.close() }
            var hasher = SHA256()
            while true {
                let chunk = try handle.read(upToCount: 1024 * 1024) ?? Data()
                if chunk.isEmpty { break }
                hasher.update(data: chunk)
            }
            return hasher.finalize().map { String(format: "%02x", $0) }.joined()
        }
    }
}

private enum ExternalFileCoordinator {
    static func read<T>(at url: URL, operation: (URL) throws -> T) throws -> T {
        var output: T?
        var operationError: Error?
        var coordinationError: NSError?

        NSFileCoordinator(filePresenter: nil).coordinate(readingItemAt: url, options: [], error: &coordinationError) { coordinatedURL in
            do { output = try operation(coordinatedURL) }
            catch { operationError = error }
        }

        if let coordinationError { throw coordinationError }
        if let operationError { throw operationError }
        guard let output else { throw CocoaError(.fileReadUnknown) }
        return output
    }
}
