import SwiftUI

struct PatchBuilderView: View {
    @EnvironmentObject private var store: AppStore
    @State private var patchName = "My configuration"
    @State private var bundleID = "com.example.app"
    @State private var relativePath = "Library/Preferences/config.json"
    @State private var note = "Created with NOVAKIT"
    @State private var payloadText = "{\n  \"enabled\": true\n}"
    @State private var exportURL: URL?
    @State private var errorMessage: String?
    @State private var showError = false

    var body: some View {
        NavigationView {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 17) {
                    header
                    targetFields
                    payloadEditor
                    buildButton
                    if let exportURL {
                        outputCard(exportURL)
                    }
                    limitationNote
                }
                .padding(18)
                .padding(.bottom, 26)
            }
            .nkScreen()
            .navigationTitle("Patch Lab")
            .navigationBarTitleDisplayMode(.inline)
            .alert("Patch package", isPresented: $showError) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(errorMessage ?? "Unable to create package")
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 7) {
            NKTag(title: "Manifest builder", color: NKTheme.violet)
            Text("Build a clean\npatch package.")
                .font(.system(size: 29, weight: .black, design: .rounded))
                .foregroundStyle(.white)
            Text("Create a portable NOVAKIT manifest for a target app and relative file path.")
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(NKTheme.muted)
                .lineSpacing(3)
        }
    }

    private var targetFields: some View {
        VStack(alignment: .leading, spacing: 11) {
            NKSectionTitle(title: "Package configuration", subtitle: "Describe the target and payload")
            field("PATCH NAME", text: $patchName, placeholder: "My configuration")
            field("TARGET BUNDLE ID", text: $bundleID, placeholder: "com.example.app", monospaced: true)
            field("RELATIVE FILE PATH", text: $relativePath, placeholder: "Library/Preferences/config.json", monospaced: true)
            field("NOTE", text: $note, placeholder: "Optional description")
        }
    }

    private func field(_ title: String, text: Binding<String>, placeholder: String, monospaced: Bool = false) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.system(size: 9, weight: .heavy, design: .rounded))
                .tracking(1.1)
                .foregroundStyle(NKTheme.muted)
            TextField(placeholder, text: text)
                .font(.system(size: 12, weight: .medium, design: monospaced ? .monospaced : .rounded))
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .padding(13)
                .background(NKTheme.surface, in: RoundedRectangle(cornerRadius: 13))
                .overlay(RoundedRectangle(cornerRadius: 13).stroke(NKTheme.line, lineWidth: 1))
        }
    }

    private var payloadEditor: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                NKSectionTitle(title: "Payload", subtitle: "UTF-8 text content")
                Spacer()
                NKTag(title: "JSON / XML / Text", color: NKTheme.cyan)
            }
            TextEditor(text: $payloadText)
                .font(.system(size: 11, design: .monospaced))
                    .foregroundStyle(.white)
                .padding(9)
                .frame(minHeight: 180)
                .background(NKTheme.surface, in: RoundedRectangle(cornerRadius: 16))
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(NKTheme.line, lineWidth: 1))
        }
    }

    private var buildButton: some View {
        Button(action: buildPackage) {
            HStack(spacing: 9) {
                Image(systemName: "hammer.fill")
                Text("Build NOVAKIT package")
                Spacer()
                Image(systemName: "arrow.right")
            }
            .font(.system(size: 13, weight: .bold))
            .foregroundStyle(NKTheme.background)
            .padding(16)
            .background(NKTheme.heroGradient, in: RoundedRectangle(cornerRadius: 15))
        }
        .buttonStyle(.plain)
    }

    private func outputCard(_ url: URL) -> some View {
        NKCard {
            VStack(alignment: .leading, spacing: 11) {
                HStack {
                    NKTag(title: "Created", color: NKTheme.green)
                    Spacer()
                    Image(systemName: "checkmark.seal.fill").foregroundStyle(NKTheme.green)
                }
                Text(url.lastPathComponent)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(.white)
                Text("Saved in NOVAKIT / Exports")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(NKTheme.muted)
                NKShareButton(url: url) {
                    Label("Share package", systemImage: "square.and.arrow.up")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(NKTheme.background)
                        .frame(maxWidth: .infinity)
                        .padding(12)
                        .background(NKTheme.cyan, in: RoundedRectangle(cornerRadius: 12))
                }
            }
        }
    }

    private var limitationNote: some View {
        HStack(alignment: .top, spacing: 9) {
            Image(systemName: "shield.lefthalf.filled")
                .foregroundStyle(NKTheme.orange)
            Text("NOVAKIT packages use the documented NOVAKIT-PATCH JSON schema. This builder does not produce compatible .3105/.1411 files, write into another app's private container, or modify game files.")
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(NKTheme.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.horizontal, 3)
    }

    private func buildPackage() {
        do {
            exportURL = try store.exportPatch(name: patchName, bundleID: bundleID,
                                              path: relativePath, text: payloadText, note: note)
        } catch {
            errorMessage = error.localizedDescription
            showError = true
        }
    }
}
