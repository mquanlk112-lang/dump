import SwiftUI

struct RootView: View {
    @State private var selection = 0

    var body: some View {
        TabView(selection: $selection) {
            HomeView(selection: $selection)
                .tabItem { Label("Home", systemImage: "square.grid.2x2.fill") }
                .tag(0)
            PackagesView()
                .tabItem { Label("Packages", systemImage: "shippingbox.fill") }
                .tag(1)
            WorkspaceView()
                .tabItem { Label("Workspace", systemImage: "folder.fill") }
                .tag(2)
            PatchBuilderView()
                .tabItem { Label("Patch Lab", systemImage: "wrench.and.screwdriver.fill") }
                .tag(3)
            DeviceView()
                .tabItem { Label("Device", systemImage: "iphone") }
                .tag(4)
        }
        .tint(NKTheme.cyan)
    }
}
