import SwiftUI
import UniformTypeIdentifiers

struct PackagesView: View {
    @EnvironmentObject private var store: AppStore
    @State private var showingImporter = false
    @State private var errorMessage: String?
    @State private var selectedPackage: PackageRecord?

    var body: some View {
        NavigationView {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    topHeader
                    importPanel
                    if store.packages.isEmpty {
                        emptyState
                    } else {
                        VStack(alignment: .leading, spacing: 11) {
                            NKSectionTitle(title: "Library", subtitle: "Stored locally inside this app")
                            ForEach(store.packages) { package in
                                packageRow(package)
                            }
                        }
                    }
                    infoNote
                }
                .padding(18)
                .padding(.bottom, 24)
            }
            .nkScreen()
            .navigationTitle("Packages")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showingImporter = true } label: {
                        Image(systemName: "plus.circle.fill").font(.system(size: 21))
                    }
                }
            }
            .fileImporter(isPresented: $showingImporter,
                          allowedContentTypes: [.item],
                          allowsMultipleSelection: true) { result in
                do {
                    let urls = try result.get()
                    try store.importPackages(urls)
                } catch {
                    errorMessage = error.localizedDescription
                }
            }
            .alert("Import failed", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("OK", role: .cancel) { errorMessage = nil }
            } message: {
                Text(errorMessage ?? "Unknown error")
            }
            .sheet(item: $selectedPackage) { package in
                PackageDetailSheet(package: package)
                    .environmentObject(store)
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .onAppear { store.refreshPackages() }
    }

    private var topHeader: some View {
        VStack(alignment: .leading, spacing: 7) {
            NKTag(title: "Package manager", color: NKTheme.cyan)
            Text("Your package\nlibrary.")
                .font(.system(size: 30, weight: .black, design: .rounded))
                .foregroundStyle(.white)
            Text("Import, identify, hash and organize package files without executing them.")
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(NKTheme.muted)
                .lineSpacing(3)
        }
    }

    private var importPanel: some View {
        Button { showingImporter = true } label: {
            NKCard(padding: 17) {
                HStack(spacing: 13) {
                    RoundedRectangle(cornerRadius: 14)
                        .fill(NKTheme.cyan.opacity(0.13))
                        .frame(width: 45, height: 45)
                        .overlay(Image(systemName: "arrow.down.doc.fill").foregroundStyle(NKTheme.cyan).font(.system(size: 18)))
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Import files")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(.white)
                        Text(".3105 · .1411 · .zip · .json · any file")
                            .font(.system(size: 10, weight: .medium))
                            .foregroundStyle(NKTheme.muted)
                    }
                    Spacer()
                    Image(systemName: "plus")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(NKTheme.cyan)
                }
            }
        }
        .buttonStyle(.plain)
    }

    private var emptyState: some View {
        NKCard {
            VStack(spacing: 12) {
                Image(systemName: "shippingbox")
                    .font(.system(size: 31, weight: .light))
                    .foregroundStyle(NKTheme.muted)
                Text("Your library is empty")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.white)
                Text("Import a package to inspect its file type, size and SHA-256 fingerprint.")
                    .font(.system(size: 11))
                    .foregroundStyle(NKTheme.muted)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
        }
    }

    private func packageRow(_ package: PackageRecord) -> some View {
        Button { selectedPackage = package } label: {
            NKCard(padding: 13) {
                HStack(spacing: 11) {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(NKTheme.violet.opacity(0.14))
                        .frame(width: 42, height: 42)
                        .overlay(Image(systemName: iconFor(package.detectedFormat))
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(NKTheme.violet))
                    VStack(alignment: .leading, spacing: 4) {
                        Text(package.name)
                            .font(.system(size: 12, weight: .bold))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                        Text("\(package.detectedFormat) · \(ByteCountFormatter.string(fromByteCount: package.byteCount, countStyle: .file))")
                            .font(.system(size: 9, weight: .medium))
                            .foregroundStyle(NKTheme.muted)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 0)
                    Image(systemName: "chevron.right")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundStyle(NKTheme.muted)
                }
            }
        }
        .buttonStyle(.plain)
    }

    private func iconFor(_ format: String) -> String {
        if format.contains("ZIP") { return "archivebox" }
        if format.contains("JSON") { return "curlybraces" }
        if format.contains("plist") { return "list.bullet.rectangle" }
        if format.contains("patch") { return "wrench.and.screwdriver" }
        return "doc.fill"
    }

    private var infoNote: some View {
        HStack(alignment: .top, spacing: 9) {
            Image(systemName: "info.circle.fill").foregroundStyle(NKTheme.orange)
            Text("Imported .3105 and .1411 files are kept as opaque packages. NOVAKIT does not claim to decode or apply another app's proprietary patch format.")
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(NKTheme.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.horizontal, 3)
    }
}

struct PackageDetailSheet: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let package: PackageRecord
    @State private var confirmDelete = false

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 15) {
                    NKCard {
                        VStack(alignment: .leading, spacing: 9) {
                            NKTag(title: package.url.pathExtension.isEmpty ? "Data file" : package.url.pathExtension + " file")
                            Text(package.name)
                                .font(.system(size: 20, weight: .bold, design: .rounded))
                                .foregroundStyle(.white)
                            Text(package.detectedFormat)
                                .font(.system(size: 11, weight: .medium))
                                .foregroundStyle(NKTheme.muted)
                        }
                    }
                    metadataRow("File size", value: ByteCountFormatter.string(fromByteCount: package.byteCount, countStyle: .file))
                    metadataRow("SHA-256", value: package.sha256, selectable: true)
                    metadataRow("Stored at", value: package.url.lastPathComponent)
                    if package.detectedFormat.contains("opaque") || ["3105", "1411"].contains(package.url.pathExtension.lowercased()) {
                        NKCard {
                            Text("This file has been imported and fingerprinted, but its proprietary payload has not been decoded or applied.")
                                .font(.system(size: 11, weight: .medium))
                                .foregroundStyle(NKTheme.orange)
                        }
                    }
                    NKShareButton(url: package.url) {
                        Label("Share / export package", systemImage: "square.and.arrow.up")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(NKTheme.background)
                            .frame(maxWidth: .infinity)
                            .padding(14)
                            .background(NKTheme.cyan, in: RoundedRectangle(cornerRadius: 14))
                    }
                    Button(role: .destructive) { confirmDelete = true } label: {
                        Label("Delete from library", systemImage: "trash")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(NKTheme.danger)
                            .frame(maxWidth: .infinity)
                            .padding(12)
                    }
                }
                .padding(18)
            }
            .nkScreen()
            .navigationTitle("Package details")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
            .confirmationDialog("Delete this package?", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Delete", role: .destructive) {
                    try? store.deletePackage(package)
                    dismiss()
                }
            }
        }
    }

    private func metadataRow(_ title: String, value: String, selectable: Bool = false) -> some View {
        NKCard(padding: 13) {
            VStack(alignment: .leading, spacing: 6) {
                Text(title.uppercased())
                    .font(.system(size: 9, weight: .heavy, design: .rounded))
                    .tracking(1)
                    .foregroundStyle(NKTheme.muted)
                Text(value)
                    .font(.system(size: 11, weight: .medium, design: selectable ? .monospaced : .rounded))
                    .foregroundStyle(.white)
                    .textSelection(.enabled)
            }
        }
    }
}
