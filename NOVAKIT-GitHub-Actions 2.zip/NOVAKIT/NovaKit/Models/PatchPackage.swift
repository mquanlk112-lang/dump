import Foundation

struct PatchPayload: Codable {
    var targetBundleID: String
    var relativePath: String
    var fileName: String
    var contentBase64: String
}

struct PatchPackage: Codable {
    var format: String = "NOVAKIT-PATCH"
    var schemaVersion: Int = 1
    var id: UUID = UUID()
    var name: String
    var createdAt: Date = Date()
    var note: String
    var payload: PatchPayload
}

enum PatchPackageError: LocalizedError {
    case invalidName
    case invalidBundleID
    case invalidPath
    case emptyPayload

    var errorDescription: String? {
        switch self {
        case .invalidName: return "Tên patch không hợp lệ."
        case .invalidBundleID: return "Bundle ID không hợp lệ. Ví dụ: com.example.app"
        case .invalidPath: return "Đường dẫn phải là đường dẫn tương đối, không được chứa .. hoặc bắt đầu bằng /."
        case .emptyPayload: return "Nội dung patch đang trống."
        }
    }
}

enum PatchPackageBuilder {
    static func make(name: String, bundleID: String, relativePath: String, text: String, note: String) throws -> Data {
        let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanName.isEmpty else { throw PatchPackageError.invalidName }

        let bundle = bundleID.trimmingCharacters(in: .whitespacesAndNewlines)
        let bundleParts = bundle.split(separator: ".")
        guard bundleParts.count >= 2,
              bundleParts.allSatisfy({ !$0.isEmpty && $0.range(of: "^[A-Za-z0-9_-]+$", options: .regularExpression) != nil })
        else { throw PatchPackageError.invalidBundleID }

        let path = relativePath.trimmingCharacters(in: .whitespacesAndNewlines)
        let pathParts = path.split(separator: "/", omittingEmptySubsequences: false)
        guard !path.isEmpty,
              !path.hasPrefix("/"),
              !pathParts.contains(".."),
              !pathParts.contains("."),
              !path.contains("\\")
        else { throw PatchPackageError.invalidPath }

        guard !text.isEmpty else { throw PatchPackageError.emptyPayload }
        let filename = URL(fileURLWithPath: path).lastPathComponent
        let payload = PatchPayload(
            targetBundleID: bundle,
            relativePath: path,
            fileName: filename,
            contentBase64: Data(text.utf8).base64EncodedString()
        )
        let package = PatchPackage(name: cleanName, note: note, payload: payload)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        return try encoder.encode(package)
    }
}
