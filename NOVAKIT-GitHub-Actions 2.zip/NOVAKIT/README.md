# NOVAKIT — iOS SwiftUI source project

A standalone iOS workspace utility inspired by the broad product areas visible in the supplied TELE/BEU IPA. The interface and implementation here are newly authored; this project does not copy the original binary or claim to be a compatible replacement for its proprietary services.

## Included, working features

- Dashboard with live local counts and activity log.
- Workspace file manager for NOVAKIT's own Documents sandbox: browse folders, import files, create folders/text files, rename, edit UTF-8 text, delete, and share/export. A separate read-only Files browser can recursively browse a directory the user explicitly selects in the iOS document picker, inspect UTF-8 text, view metadata and SHA-256, and export the original file.
- Package library: import `.3105`, `.1411`, `.zip`, `.json`, and other files; identify common ZIP/JSON/plist signatures; calculate file size and SHA-256; share or delete stored packages.
- Patch Lab: validate a bundle ID and relative path, then create a portable `NOVAKIT-PATCH` JSON package (`.novapatch`) containing the text payload.
- Read-only device information using standard public iOS APIs.
- Dark violet/cyan SwiftUI design, custom app icon and developer credit; iOS 15+ deployment target.

## Deliberate compatibility boundaries

Imported `.3105` and `.1411` files are stored and fingerprinted as opaque files. They are **not** decoded or applied. The `.novapatch` schema is NOVAKIT's own format and is not compatible with 3105/BEU.

The Files browser uses a security-scoped URL returned after the user selects a folder in Files. It does not gain unrestricted filesystem access and cannot read or write another app's private container (for example, a game bundle) unless that app explicitly exports those files to a user-accessible location. The browser is read-only for selected external folders. iOS app sandbox rules apply. It does not include the original app's Firebase/license backend, remote endpoints, credentials, certificates, or provisioning profiles.

## Build an IPA in Xcode

Requirements: macOS with Xcode 15 or later and an Apple signing identity. This Linux environment cannot run Xcode or sign an iOS application, so this delivery is the complete source project, not a prebuilt IPA.

1. Unzip the project and open `NOVAKIT.xcodeproj` in Xcode.
2. Select the `NOVAKIT` scheme and an iPhone device or `Any iOS Device (arm64)`.
3. In **Signing & Capabilities**, enable **Automatically manage signing** and select your Team. Change `com.minhquandev.novakit` if you need a different bundle identifier.
4. Build and run on a device, or choose **Product → Archive**.
5. In Organizer, choose the archive → **Distribute App** → select the signing/distribution method appropriate for your device. Xcode exports the signed IPA.

## Project structure

```text
NOVAKIT/
├── NOVAKIT.xcodeproj/
│   └── xcshareddata/xcschemes/NOVAKIT.xcscheme
├── NovaKit/
│   ├── NovaKitApp.swift
│   ├── Assets.xcassets/
│   │   └── AppIcon.appiconset/
│   ├── Core/
│   │   ├── AppStore.swift
│   │   └── Theme.swift
│   ├── Models/
│   │   └── PatchPackage.swift
│   └── Views/
│       ├── RootView.swift
│       ├── HomeView.swift
│       ├── PackagesView.swift
│       ├── WorkspaceView.swift
│       ├── ExternalFilesView.swift
│       ├── PatchBuilderView.swift
│       ├── DeviceView.swift
│       └── SettingsView.swift
└── README.md
```

## Package format

`.novapatch` is UTF-8 JSON with `format: "NOVAKIT-PATCH"`, `schemaVersion: 1`, and a single payload containing the target bundle identifier, relative path, filename, and Base64-encoded content. It is a portable manifest only; NOVAKIT does not write that payload into the named third-party app.
